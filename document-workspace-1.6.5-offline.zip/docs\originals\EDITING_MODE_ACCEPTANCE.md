﻿# EDITING MODE ACCEPTANCE

此文件为历史占位文档，当前版本已收敛到主文档体系。

请参考：
- docs/overview/README_INDEX.md
- docs/USER_MANUAL.md
- docs/SOP_DEPOSIT_GUIDE.md
- docs/PROJECT_REVIEW.md
