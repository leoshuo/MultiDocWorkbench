﻿/**
 * 集成步骤（已简化）
 * 1.6 版本已内置布局编辑与按钮配置，通常无需手工集成。
 * 如需二次开发，请参考 docs/USER_MANUAL.md。
 */

export const IntegrationChecklist = [];

export default {
  IntegrationChecklist,
};

