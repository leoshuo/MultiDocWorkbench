/**
 * 共享模块导出
 * 提供跨工作台使用的通用组件和工具
 */

export { ErrorBoundary, withErrorBoundary } from './ErrorBoundary';
